import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProgressbarRecord extends FirestoreRecord {
  ProgressbarRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "count" field.
  int? _count;
  int get count => _count ?? 0;
  bool hasCount() => _count != null;

  // "count2" field.
  int? _count2;
  int get count2 => _count2 ?? 0;
  bool hasCount2() => _count2 != null;

  // "count3" field.
  int? _count3;
  int get count3 => _count3 ?? 0;
  bool hasCount3() => _count3 != null;

  void _initializeFields() {
    _count = castToType<int>(snapshotData['count']);
    _count2 = castToType<int>(snapshotData['count2']);
    _count3 = castToType<int>(snapshotData['count3']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('progressbar');

  static Stream<ProgressbarRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ProgressbarRecord.fromSnapshot(s));

  static Future<ProgressbarRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ProgressbarRecord.fromSnapshot(s));

  static ProgressbarRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ProgressbarRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ProgressbarRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ProgressbarRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ProgressbarRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ProgressbarRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createProgressbarRecordData({
  int? count,
  int? count2,
  int? count3,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'count': count,
      'count2': count2,
      'count3': count3,
    }.withoutNulls,
  );

  return firestoreData;
}

class ProgressbarRecordDocumentEquality implements Equality<ProgressbarRecord> {
  const ProgressbarRecordDocumentEquality();

  @override
  bool equals(ProgressbarRecord? e1, ProgressbarRecord? e2) {
    return e1?.count == e2?.count &&
        e1?.count2 == e2?.count2 &&
        e1?.count3 == e2?.count3;
  }

  @override
  int hash(ProgressbarRecord? e) =>
      const ListEquality().hash([e?.count, e?.count2, e?.count3]);

  @override
  bool isValidKey(Object? o) => o is ProgressbarRecord;
}
