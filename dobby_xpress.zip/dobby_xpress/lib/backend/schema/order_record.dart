import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OrderRecord extends FirestoreRecord {
  OrderRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "source" field.
  LatLng? _source;
  LatLng? get source => _source;
  bool hasSource() => _source != null;

  // "destination" field.
  LatLng? _destination;
  LatLng? get destination => _destination;
  bool hasDestination() => _destination != null;

  // "distanceleft" field.
  String? _distanceleft;
  String get distanceleft => _distanceleft ?? '';
  bool hasDistanceleft() => _distanceleft != null;

  // "timeleft" field.
  String? _timeleft;
  String get timeleft => _timeleft ?? '';
  bool hasTimeleft() => _timeleft != null;

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  bool hasUsername() => _username != null;

  // "driverposition" field.
  List<LatLng>? _driverposition;
  List<LatLng> get driverposition => _driverposition ?? const [];
  bool hasDriverposition() => _driverposition != null;

  // "pickup" field.
  LatLng? _pickup;
  LatLng? get pickup => _pickup;
  bool hasPickup() => _pickup != null;

  void _initializeFields() {
    _source = snapshotData['source'] as LatLng?;
    _destination = snapshotData['destination'] as LatLng?;
    _distanceleft = snapshotData['distanceleft'] as String?;
    _timeleft = snapshotData['timeleft'] as String?;
    _username = snapshotData['username'] as String?;
    _driverposition = getDataList(snapshotData['driverposition']);
    _pickup = snapshotData['pickup'] as LatLng?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('order');

  static Stream<OrderRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => OrderRecord.fromSnapshot(s));

  static Future<OrderRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => OrderRecord.fromSnapshot(s));

  static OrderRecord fromSnapshot(DocumentSnapshot snapshot) => OrderRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static OrderRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      OrderRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'OrderRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is OrderRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createOrderRecordData({
  LatLng? source,
  LatLng? destination,
  String? distanceleft,
  String? timeleft,
  String? username,
  LatLng? pickup,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'source': source,
      'destination': destination,
      'distanceleft': distanceleft,
      'timeleft': timeleft,
      'username': username,
      'pickup': pickup,
    }.withoutNulls,
  );

  return firestoreData;
}

class OrderRecordDocumentEquality implements Equality<OrderRecord> {
  const OrderRecordDocumentEquality();

  @override
  bool equals(OrderRecord? e1, OrderRecord? e2) {
    const listEquality = ListEquality();
    return e1?.source == e2?.source &&
        e1?.destination == e2?.destination &&
        e1?.distanceleft == e2?.distanceleft &&
        e1?.timeleft == e2?.timeleft &&
        e1?.username == e2?.username &&
        listEquality.equals(e1?.driverposition, e2?.driverposition) &&
        e1?.pickup == e2?.pickup;
  }

  @override
  int hash(OrderRecord? e) => const ListEquality().hash([
        e?.source,
        e?.destination,
        e?.distanceleft,
        e?.timeleft,
        e?.username,
        e?.driverposition,
        e?.pickup
      ]);

  @override
  bool isValidKey(Object? o) => o is OrderRecord;
}
