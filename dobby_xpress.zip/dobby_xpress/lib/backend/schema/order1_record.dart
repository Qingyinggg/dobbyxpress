import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Order1Record extends FirestoreRecord {
  Order1Record._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "destination" field.
  String? _destination;
  String get destination => _destination ?? '';
  bool hasDestination() => _destination != null;

  // "driverpostion" field.
  List<String>? _driverpostion;
  List<String> get driverpostion => _driverpostion ?? const [];
  bool hasDriverpostion() => _driverpostion != null;

  // "distanceleft" field.
  List<String>? _distanceleft;
  List<String> get distanceleft => _distanceleft ?? const [];
  bool hasDistanceleft() => _distanceleft != null;

  // "timeleft" field.
  List<String>? _timeleft;
  List<String> get timeleft => _timeleft ?? const [];
  bool hasTimeleft() => _timeleft != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  void _initializeFields() {
    _destination = snapshotData['destination'] as String?;
    _driverpostion = getDataList(snapshotData['driverpostion']);
    _distanceleft = getDataList(snapshotData['distanceleft']);
    _timeleft = getDataList(snapshotData['timeleft']);
    _location = snapshotData['location'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('order1');

  static Stream<Order1Record> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => Order1Record.fromSnapshot(s));

  static Future<Order1Record> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => Order1Record.fromSnapshot(s));

  static Order1Record fromSnapshot(DocumentSnapshot snapshot) => Order1Record._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static Order1Record getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      Order1Record._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'Order1Record(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is Order1Record &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createOrder1RecordData({
  String? destination,
  String? location,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'destination': destination,
      'location': location,
    }.withoutNulls,
  );

  return firestoreData;
}

class Order1RecordDocumentEquality implements Equality<Order1Record> {
  const Order1RecordDocumentEquality();

  @override
  bool equals(Order1Record? e1, Order1Record? e2) {
    const listEquality = ListEquality();
    return e1?.destination == e2?.destination &&
        listEquality.equals(e1?.driverpostion, e2?.driverpostion) &&
        listEquality.equals(e1?.distanceleft, e2?.distanceleft) &&
        listEquality.equals(e1?.timeleft, e2?.timeleft) &&
        e1?.location == e2?.location;
  }

  @override
  int hash(Order1Record? e) => const ListEquality().hash([
        e?.destination,
        e?.driverpostion,
        e?.distanceleft,
        e?.timeleft,
        e?.location
      ]);

  @override
  bool isValidKey(Object? o) => o is Order1Record;
}
