// Export pages
export '/start/home_page/home_page_widget.dart' show HomePageWidget;
export '/start/login/login_widget.dart' show LoginWidget;
export '/start/create_account1/create_account1_widget.dart'
    show CreateAccount1Widget;
export '/option/services/services_widget.dart' show ServicesWidget;
export '/option/drypage/drypage_widget.dart' show DrypageWidget;
export '/outcome/order/order_widget.dart' show OrderWidget;
export '/profile/profile/profile_widget.dart' show ProfileWidget;
export '/start/privacypolicy/privacypolicy_widget.dart'
    show PrivacypolicyWidget;
export '/option/washpage/washpage_widget.dart' show WashpageWidget;
export '/option/washanddrypage/washanddrypage_widget.dart'
    show WashanddrypageWidget;
export '/outcome/payment/payment_widget.dart' show PaymentWidget;
export '/outcome/trackorder/trackorder_widget.dart' show TrackorderWidget;
export '/profile/historypage/historypage_widget.dart' show HistorypageWidget;
export '/option/location/location_widget.dart' show LocationWidget;
export '/outcome/livelocation/livelocation_widget.dart' show LivelocationWidget;
export '/outcome/orderplaced/orderplaced_widget.dart' show OrderplacedWidget;
export '/outcome/cancelorder/cancelorder_widget.dart' show CancelorderWidget;
