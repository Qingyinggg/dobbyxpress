import 'package:flutter/material.dart';
import '/backend/backend.dart';
import 'backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  String _service = '';
  String get service => _service;
  set service(String _value) {
    _service = _value;
  }

  String _quantity = '';
  String get quantity => _quantity;
  set quantity(String _value) {
    _quantity = _value;
  }

  String _location = '';
  String get location => _location;
  set location(String _value) {
    _location = _value;
  }

  String _timeslot = '';
  String get timeslot => _timeslot;
  set timeslot(String _value) {
    _timeslot = _value;
  }

  double _price = 0.0;
  double get price => _price;
  set price(double _value) {
    _price = _value;
  }

  double _progress = 0.0;
  double get progress => _progress;
  set progress(double _value) {
    _progress = _value;
  }

  int _count = 0;
  int get count => _count;
  set count(int _value) {
    _count = _value;
  }

  int _count2 = 0;
  int get count2 => _count2;
  set count2(int _value) {
    _count2 = _value;
  }

  int _count3 = 0;
  int get count3 => _count3;
  set count3(int _value) {
    _count3 = _value;
  }

  String _username = '';
  String get username => _username;
  set username(String _value) {
    _username = _value;
  }

  String _destination = '';
  String get destination => _destination;
  set destination(String _value) {
    _destination = _value;
  }
}

LatLng? _latLngFromString(String? val) {
  if (val == null) {
    return null;
  }
  final split = val.split(',');
  final lat = double.parse(split.first);
  final lng = double.parse(split.last);
  return LatLng(lat, lng);
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
